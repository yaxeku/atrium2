import"./Bzak7iHL.js";import{y as i,z as m,a as n}from"./CL1ai2Yl.js";import{s as p}from"./BKOYs9ZV.js";function c(r,o){var a=i(),t=m(a);p(t,()=>o.children),n(r,a)}export{c as L};
