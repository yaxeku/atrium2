import{L as m}from"../chunks/CjK9QoIm.js";export{m as component};
